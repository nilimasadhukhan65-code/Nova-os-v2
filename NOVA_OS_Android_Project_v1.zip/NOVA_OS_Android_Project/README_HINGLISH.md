# NOVA OS Android Launcher — Starter v1.0

Ye Android launcher ka starter project hai, compiled APK nahi.

## Features in this starter
- Landscape-only launcher activity
- Android HOME launcher intent
- Installed launchable apps ki library
- App tap karke launch
- RAM availability aur Android thermal status display
- Touch ke saath Android ke normal Bluetooth/USB keyboard, mouse aur controller input support

## Important limitations
- Ye Android OS replacement nahi, launcher app hai.
- Android third-party launcher ko dusre apps force-stop karne, CPU/GPU clocks lock karne, ya guaranteed FPS boost dene ki permission nahi deta.
- Booster abhi status/diagnostic screen hai; "Optimize Check" sirf status refresh karta hai.
- Game library abhi sab launchable apps dikhati hai; game-only filtering/favourites/manual curation next iteration mein add karni hogi.
- Android 9+ supported (minSdk 26). POCO F1 / Android 9 target compatible.

## Build APK with GitHub Actions
1. ZIP extract karke files GitHub repository mein upload karo.
2. `.github/workflows/android.yml` workflow included hai.
3. GitHub repo → Actions → "Build NOVA OS APK" → Run workflow.
4. Build complete hone par `nova-os-debug-apk` artifact download karo.
5. APK phone par install karo. Install ke baad Home button press karke NOVA OS choose karo; "Always" select kar sakte ho.

Debug APK test build hai, Play Store release signing nahi.
